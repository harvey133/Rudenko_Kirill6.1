# MTO_laba6.1Python
![srcreenshot](11.png)
![srcreenshot](23.png)
![srcreenshot](45.png)
![srcreenshot](4.png)
